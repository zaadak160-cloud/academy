import React, { useState, useEffect } from 'react';
import { Play, BookOpen, CheckCircle, Clock, Users, Award, ChevronRight, Menu, X, Star, Download, MessageCircle, Video, FileText, Plus, Edit3, Trash2, Save, Upload, Eye } from 'lucide-react';

const App = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('curriculum');
  const [completedLessons, setCompletedLessons] = useState(new Set([0, 1]));
  const [showAddModule, setShowAddModule] = useState(false);
  const [showAddLesson, setShowAddLesson] = useState(false);
  const [selectedModule, setSelectedModule] = useState(null);
  const [editingModule, setEditingModule] = useState(null);
  const [editingLesson, setEditingLesson] = useState(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  // حالة المنهج القابلة للتعديل
  const [curriculum, setCurriculum] = useState([
    {
      id: 1,
      title: "مقدمة إلى وكلاء الذكاء الاصطناعي",
      description: "افهم المفاهيم الأساسية وحالات الاستخدام العملية",
      lessons: [
        { id: 0, title: "مقدمة عن الدورة", duration: "8 دقائق", type: "video", completed: true },
        { id: 1, title: "ما هو وكيل الذكاء الاصطناعي؟", duration: "12 دقائق", type: "video", completed: true },
        { id: 2, title: "حالات الاستخدام العملية", duration: "15 دقائق", type: "video", completed: false },
        { id: 3, title: "اختبار: أساسيات وكلاء الذكاء الاصطناعي", duration: "10 دقائق", type: "quiz", completed: false }
      ]
    },
    {
      id: 2,
      title: "بناء أول وكيل ذكاء اصطناعي",
      description: "تعلم الخطوات العملية لبناء وكيل ذكاء اصطناعي من الصفر",
      lessons: [
        { id: 4, title: "إعداد بيئة التطوير", duration: "20 دقائق", type: "video", completed: false },
        { id: 5, title: "كتابة أول سطر كود", duration: "25 دقائق", type: "video", completed: false },
        { id: 6, title: "اختبار الوكيل", duration: "18 دقائق", type: "video", completed: false }
      ]
    }
  ]);

  const course = {
    title: "أساسيات وكلاء الذكاء الاصطناعي",
    instructor: "د. محمد أحمد",
    duration: "4 ساعات",
    level: "مبتدئ",
    students: "2,347",
    rating: 4.9,
    description: "تعلم كيفية بناء وكلاء ذكاء اصطناعي قادرين على اتخاذ القرارات وتنفيذ المهام بشكل مستقل باستخدام أحدث التقنيات والمنصات.",
    image: "https://placehold.co/800x450/6366f1/ffffff?text=AI+Agents+Foundation",
    subtitle: "ابدأ رحلتك في عالم وكلاء الذكاء الاصطناعي وتعلم بناء أنظمة ذكية قادرة على التفكير والعمل بشكل مستقل"
  };

  // وظائف إدارة المنهج
  const addModule = (moduleData) => {
    const newModule = {
      id: Date.now(),
      title: moduleData.title,
      description: moduleData.description,
      lessons: []
    };
    setCurriculum([...curriculum, newModule]);
    setShowAddModule(false);
  };

  const addLesson = (lessonData) => {
    const updatedCurriculum = curriculum.map(module => {
      if (module.id === selectedModule) {
        return {
          ...module,
          lessons: [...module.lessons, {
            id: Date.now(),
            title: lessonData.title,
            duration: lessonData.duration,
            type: lessonData.type,
            completed: false
          }]
        };
      }
      return module;
    });
    setCurriculum(updatedCurriculum);
    setShowAddLesson(false);
    setSelectedModule(null);
  };

  const deleteModule = (moduleId) => {
    setCurriculum(curriculum.filter(module => module.id !== moduleId));
  };

  const deleteLesson = (moduleId, lessonId) => {
    const updatedCurriculum = curriculum.map(module => {
      if (module.id === moduleId) {
        return {
          ...module,
          lessons: module.lessons.filter(lesson => lesson.id !== lessonId)
        };
      }
      return module;
    });
    setCurriculum(updatedCurriculum);
  };

  const updateModule = (moduleId, updatedData) => {
    const updatedCurriculum = curriculum.map(module => {
      if (module.id === moduleId) {
        return { ...module, ...updatedData };
      }
      return module;
    });
    setCurriculum(updatedCurriculum);
    setEditingModule(null);
  };

  const updateLesson = (moduleId, lessonId, updatedData) => {
    const updatedCurriculum = curriculum.map(module => {
      if (module.id === moduleId) {
        return {
          ...module,
          lessons: module.lessons.map(lesson => {
            if (lesson.id === lessonId) {
              return { ...lesson, ...updatedData };
            }
            return lesson;
          })
        };
      }
      return module;
    });
    setCurriculum(updatedCurriculum);
    setEditingLesson(null);
  };

  const toggleLesson = (lessonId) => {
    const newCompleted = new Set(completedLessons);
    if (newCompleted.has(lessonId)) {
      newCompleted.delete(lessonId);
    } else {
      newCompleted.add(lessonId);
    }
    setCompletedLessons(newCompleted);
  };

  const getProgress = () => {
    const totalLessons = curriculum.reduce((acc, module) => acc + module.lessons.length, 0);
    return totalLessons > 0 ? Math.round((completedLessons.size / totalLessons) * 100) : 0;
  };

  const getLessonIcon = (type) => {
    switch (type) {
      case 'video':
        return <Play className="w-4 h-4" />;
      case 'quiz':
        return <MessageCircle className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const getTotalDuration = () => {
    return curriculum.reduce((total, module) => {
      return total + module.lessons.reduce((moduleTotal, lesson) => {
        const minutes = parseInt(lesson.duration);
        return moduleTotal + (isNaN(minutes) ? 0 : minutes);
      }, 0);
    }, 0);
  };

  // مكونات النماذج
  const AddModuleModal = () => {
    const [formData, setFormData] = useState({ title: '', description: '' });

    const handleSubmit = (e) => {
      e.preventDefault();
      if (formData.title.trim()) {
        addModule(formData);
        setFormData({ title: '', description: '' });
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900">إضافة وحدة جديدة</h3>
            <button onClick={() => setShowAddModule(false)} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">عنوان الوحدة</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">الوصف</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                rows="3"
              />
            </div>
            <div className="flex space-x-3">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all"
              >
                إضافة الوحدة
              </button>
              <button
                type="button"
                onClick={() => setShowAddModule(false)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-300 transition-all"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const AddLessonModal = () => {
    const [formData, setFormData] = useState({ title: '', duration: '', type: 'video' });

    const handleSubmit = (e) => {
      e.preventDefault();
      if (formData.title.trim() && formData.duration.trim()) {
        addLesson(formData);
        setFormData({ title: '', duration: '', type: 'video' });
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900">إضافة درس جديد</h3>
            <button onClick={() => { setShowAddLesson(false); setSelectedModule(null); }} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">عنوان الدرس</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">المدة</label>
              <input
                type="text"
                placeholder="مثال: 15 دقائق"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">نوع المحتوى</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="video">فيديو</option>
                <option value="quiz">اختبار</option>
                <option value="text">نص</option>
              </select>
            </div>
            <div className="flex space-x-3">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all"
              >
                إضافة الدرس
              </button>
              <button
                type="button"
                onClick={() => { setShowAddLesson(false); setSelectedModule(null); }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-300 transition-all"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const EditModuleModal = () => {
    const [formData, setFormData] = useState({
      title: editingModule?.title || '',
      description: editingModule?.description || ''
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      if (formData.title.trim()) {
        updateModule(editingModule.id, formData);
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900">تعديل الوحدة</h3>
            <button onClick={() => setEditingModule(null)} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">عنوان الوحدة</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">الوصف</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                rows="3"
              />
            </div>
            <div className="flex space-x-3">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all"
              >
                حفظ التعديلات
              </button>
              <button
                type="button"
                onClick={() => setEditingModule(null)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-300 transition-all"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const EditLessonModal = () => {
    const [formData, setFormData] = useState({
      title: editingLesson?.title || '',
      duration: editingLesson?.duration || '',
      type: editingLesson?.type || 'video'
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      if (formData.title.trim() && formData.duration.trim()) {
        updateLesson(editingLesson.moduleId, editingLesson.lessonId, formData);
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900">تعديل الدرس</h3>
            <button onClick={() => setEditingLesson(null)} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">عنوان الدرس</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">المدة</label>
              <input
                type="text"
                placeholder="مثال: 15 دقائق"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">نوع المحتوى</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="video">فيديو</option>
                <option value="quiz">اختبار</option>
                <option value="text">نص</option>
              </select>
            </div>
            <div className="flex space-x-3">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 rounded-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all"
              >
                حفظ التعديلات
              </button>
              <button
                type="button"
                onClick={() => setEditingLesson(null)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-300 transition-all"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-gray-900 text-lg">أكاديمية الذكاء الاصطناعي</span>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <nav className="flex space-x-6">
                <a href="#" className="text-gray-700 hover:text-indigo-600 font-medium transition-colors">الدورات</a>
                <a href="#" className="text-gray-700 hover:text-indigo-600 font-medium transition-colors">الشهادات</a>
                <a href="#" className="text-gray-700 hover:text-indigo-600 font-medium transition-colors">المجتمع</a>
                <a href="#" className="text-gray-700 hover:text-indigo-600 font-medium transition-colors">المدونة</a>
              </nav>
              <button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm hover:shadow-md">
                تسجيل الدخول
              </button>
            </div>

            <button 
              className="md:hidden text-gray-600 hover:text-gray-900"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b shadow-lg">
          <div className="px-4 py-4 space-y-3">
            <a href="#" className="block py-2 text-gray-700 hover:text-indigo-600 font-medium">الدورات</a>
            <a href="#" className="block py-2 text-gray-700 hover:text-indigo-600 font-medium">الشهادات</a>
            <a href="#" className="block py-2 text-gray-700 hover:text-indigo-600 font-medium">المجتمع</a>
            <a href="#" className="block py-2 text-gray-700 hover:text-indigo-600 font-medium">المدونة</a>
            <button className="w-full mt-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-lg font-medium shadow-sm">
              تسجيل الدخول
            </button>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Course Info */}
            <div className="lg:col-span-2">
              <div className="mb-4">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                  <BookOpen className="w-4 h-4 mr-1.5" />
                  {course.level}
                </span>
              </div>
              
              <h1 className="text-4xl font-bold text-gray-900 mb-4 leading-tight">
                {course.title}
              </h1>
              
              <p className="text-xl text-gray-600 mb-6 leading-relaxed">
                {course.subtitle}
              </p>
              
              <p className="text-gray-700 text-lg mb-8 leading-relaxed">
                {course.description}
              </p>
              
              <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600 mb-8">
                <div className="flex items-center">
                  <Users className="w-5 h-5 mr-2 text-indigo-600" />
                  <span className="font-medium">{course.students}+</span> طالب مسجل
                </div>
                <div className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-indigo-600" />
                  <span className="font-medium">{getTotalDuration()} دقيقة</span> محتوى
                </div>
                <div className="flex items-center">
                  <Star className="w-5 h-5 mr-2 text-yellow-400 fill-current" />
                  <span className="font-medium">{course.rating}</span> تقييم ({course.students} تقييم)
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <button className="inline-flex items-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl">
                  <Play className="w-5 h-5 mr-2" />
                  ابدأ التعلم الآن
                </button>
                <button className="inline-flex items-center border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-all">
                  <Download className="w-5 h-5 mr-2" />
                  تحميل المنهج
                </button>
                <button 
                  onClick={() => setIsPreviewMode(!isPreviewMode)}
                  className="inline-flex items-center border-2 border-indigo-600 text-indigo-600 px-6 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition-all"
                >
                  <Eye className="w-5 h-5 mr-2" />
                  {isPreviewMode ? 'وضع التحرير' : 'معاينة المنهج'}
                </button>
              </div>
            </div>
            
            {/* Progress Card */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm sticky top-24">
                <div className="mb-6">
                  <div className="aspect-video bg-gradient-to-br from-indigo-400 to-purple-500 rounded-xl mb-4 overflow-hidden">
                    <img 
                      src={course.image} 
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-semibold text-gray-900">تقدمك</span>
                    <span className="text-indigo-600 font-bold">{getProgress()}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${getProgress()}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    {completedLessons.size} من أصل {curriculum.reduce((acc, module) => acc + module.lessons.length, 0)} درس مكتمل
                  </p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <Award className="w-4 h-4 mr-2 text-green-500" />
                    شهادة إتمام معتمدة
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="w-4 h-4 mr-2 text-blue-500" />
                    وصول مدى الحياة للمحتوى
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <MessageCircle className="w-4 h-4 mr-2 text-purple-500" />
                    دعم فني مخصص
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto scrollbar-hide">
            {[
              { id: 'curriculum', label: 'المنهج الدراسي', icon: BookOpen },
              { id: 'overview', label: 'نظرة عامة', icon: FileText },
              { id: 'instructor', label: 'المدرب', icon: Users },
              { id: 'reviews', label: 'التقييمات', icon: Star }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center py-6 px-1 font-medium whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'text-indigo-600 border-indigo-600'
                    : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                <tab.icon className="w-4 h-4 mr-2" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Course Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">وصف الدورة التدريبية</h2>
                <div className="prose prose-lg max-w-none">
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    في هذه الدورة الشاملة، ستتعلم كيفية بناء وكلاء ذكاء اصطناعي قادرين على اتخاذ القرارات وتنفيذ المهام بشكل مستقل. 
                    سنبدأ من الأساسيات ونتقدم تدريجياً إلى المفاهيم المتقدمة، مع أمثلة عملية وتطبيقات واقعية.
                  </p>
                  <p className="text-gray-700 mb-8 leading-relaxed">
                    سواء كنت مطوراً مبتدئاً أو محترفاً، ستجد في هذه الدورة المحتوى المناسب لمستواك. 
                    سنغطي كل شيء من إعداد بيئة التطوير إلى نشر الوكيل في بيئة الإنتاج.
                  </p>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-4">ماذا ستتعلم في هذه الدورة؟</h3>
                  <ul className="space-y-3 mb-8">
                    {[
                      "فهم مفاهيم وكلاء الذكاء الاصطناعي الأساسية والمتقدمة",
                      "بناء أول وكيل ذكاء اصطناعي من الصفر باستخدام لغة Python",
                      "التكامل مع الأدوات والخدمات الخارجية مثل APIs وقواعد البيانات",
                      "اختبار وتحسين أداء الوكلاء الذكية",
                      "نشر ونشر أنظمة الذكاء الاصطناعي في بيئة الإنتاج"
                    ].map((item, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-bold text-gray-900 mb-4">المتطلبات الأساسية</h3>
                <ul className="space-y-3 text-gray-700">
                  {[
                    "معرفة أساسية بلغة البرمجة Python",
                    "فهم مبدئي لمفاهيم الذكاء الاصطناعي والتعلم الآلي",
                    "جهاز كمبيوتر مع اتصال بالإنترنت",
                    "حساب مجاني على منصات الذكاء الاصطناعي (سيتم توفير الروابط)"
                  ].map((req, index) => (
                    <li key={index} className="flex items-start">
                      <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2.5 mr-3 flex-shrink-0"></div>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-bold text-gray-900 mb-4">لمن هذه الدورة؟</h3>
                <ul className="space-y-3 text-gray-700">
                  {[
                    "المطورون الراغبون في تعلم تقنيات الذكاء الاصطناعي الحديثة",
                    "رواد الأعمال المهتمون ببناء حلول ذكية لشركاتهم",
                    "الطلاب في مجالات علوم الحاسوب والهندسة",
                    "المهنيون الراغبون في تطوير مهاراتهم في الذكاء الاصطناعي"
                  ].map((audience, index) => (
                    <li key={index} className="flex items-start">
                      <div className="w-2 h-2 bg-purple-600 rounded-full mt-2.5 mr-3 flex-shrink-0"></div>
                      <span>{audience}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'curriculum' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">المنهج الدراسي الكامل</h2>
                  <p className="text-gray-600 mt-2">
                    {curriculum.length} وحدات • {curriculum.reduce((acc, module) => acc + module.lessons.length, 0)} درس • {getTotalDuration()} دقيقة محتوى
                  </p>
                </div>
                <div className="text-right">
                  {!isPreviewMode && (
                    <button
                      onClick={() => setShowAddModule(true)}
                      className="inline-flex items-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      إضافة وحدة
                    </button>
                  )}
                </div>
              </div>
              
              <div className="space-y-6">
                {curriculum.map((module, moduleIndex) => (
                  <div key={module.id} className="border border-gray-200 rounded-xl overflow-hidden">
                    <div className="bg-gray-50 px-6 py-5">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">الوحدة {moduleIndex + 1}: {module.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{module.description}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500">
                            {module.lessons.length} دروس • {module.lessons.reduce((acc, lesson) => acc + parseInt(lesson.duration), 0)} دقيقة
                          </span>
                          {!isPreviewMode && (
                            <div className="flex space-x-1">
                              <button
                                onClick={() => setEditingModule(module)}
                                className="p-1 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 rounded"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => deleteModule(module.id)}
                                className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  setSelectedModule(module.id);
                                  setShowAddLesson(true);
                                }}
                                className="p-1 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="divide-y divide-gray-100">
                      {module.lessons.map((lesson) => (
                        <div 
                          key={lesson.id} 
                          className={`px-6 py-4 hover:bg-gray-50 cursor-pointer transition-colors ${
                            !isPreviewMode ? 'cursor-default' : ''
                          }`}
                          onClick={() => isPreviewMode && toggleLesson(lesson.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                                lesson.completed 
                                  ? 'bg-green-100 text-green-600' 
                                  : 'bg-gray-100 text-gray-500'
                              }`}>
                                {lesson.completed ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : (
                                  getLessonIcon(lesson.type)
                                )}
                              </div>
                              <div className="min-w-0">
                                <h4 className="font-medium text-gray-900 truncate">{lesson.title}</h4>
                                <div className="flex items-center mt-1">
                                  <Clock className="w-3 h-3 text-gray-400 mr-1" />
                                  <span className="text-xs text-gray-500">{lesson.duration}</span>
                                </div>
                              </div>
                            </div>
                            {!isPreviewMode && (
                              <div className="flex space-x-1">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingLesson({ moduleId: module.id, lessonId: lesson.id, ...lesson });
                                  }}
                                  className="p-1 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 rounded"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteLesson(module.id, lesson.id);
                                  }}
                                  className="p-1 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'instructor' && (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-1/4 flex-shrink-0">
                <div className="w-32 h-32 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto shadow-lg">
                  {course.instructor.split(' ').map(n => n[0]).join('')}
                </div>
              </div>
              <div className="md:w-3/4">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{course.instructor}</h2>
                <p className="text-indigo-600 font-medium text-lg mb-6">خبير في الذكاء الاصطناعي وتعلم الآلة</p>
                
                <div className="prose prose-lg max-w-none mb-8">
                  <p className="text-gray-700 mb-4 leading-relaxed">
                    د. محمد أحمد هو باحث ومهندس في مجال الذكاء الاصطناعي مع أكثر من 10 سنوات من الخبرة في تطوير حلول الذكاء الاصطناعي. 
                    حاصل على الدكتوراه في علوم الحاسوب من جامعة ستانفورد، وعمل مع شركات تقنية كبرى على تطوير أنظمة ذكاء اصطناعي متقدمة.
                  </p>
                  <p className="text-gray-700 mb-4 leading-relaxed">
                    قام بتدريب أكثر من 10,000 طالب حول العالم، وطور مناهج تعليمية مبتكرة في مجالات الذكاء الاصطناعي وتعلم الآلة.
                    يتميز أسلوبه التعليمي بالوضوح والتركيز على التطبيقات العملية.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-gray-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-indigo-600">12+</div>
                    <div className="text-sm text-gray-600">دورة</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-indigo-600">45K+</div>
                    <div className="text-sm text-gray-600">طالب</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-indigo-600">4.9</div>
                    <div className="text-sm text-gray-600">تقييم</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900">تقييمات الطلاب</h2>
              <div className="text-right">
                <div className="flex items-center">
                  <div className="text-3xl font-bold text-gray-900 mr-2">{course.rating}</div>
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-6 h-6 ${i < Math.floor(course.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                      />
                    ))}
                  </div>
                </div>
                <div className="text-sm text-gray-600">بناءً على {course.students} تقييم</div>
              </div>
            </div>
            
            <div className="space-y-6">
              {[
                {
                  name: "أحمد السعدي",
                  role: "مهندس برمجيات",
                  rating: 5,
                  date: "منذ أسبوع",
                  comment: "دورة ممتازة وشاملة! الشرح واضح والتطبيقات عملية جداً. أنصح بها لكل من يريد تعلم بناء وكلاء الذكاء الاصطناعي."
                },
                {
                  name: "سارة محمد",
                  role: "رائدة أعمال",
                  rating: 5,
                  date: "منذ أسبوعين",
                  comment: "المحتوى ممتاز والدكتور محمد شرحه مبسط جداً حتى للمبتدئين. الدورة تستحق كل دقيقة فيها!"
                },
                {
                  name: "خالد عبدالله",
                  role: "طالب جامعي",
                  rating: 5,
                  date: "منذ 3 أسابيع",
                  comment: "أفضل دورة في مجال وكلاء الذكاء الاصطناعي. التطبيق العملي جعلني أفهم المفاهيم بشكل أعمق."
                }
              ].map((review, index) => (
                <div key={index} className="border-b border-gray-100 pb-6 last:border-b-0 last:pb-0">
                  <div className="flex items-start mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center text-white font-bold text-sm mr-4 flex-shrink-0">
                      {review.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-900">{review.name}</h4>
                          <p className="text-sm text-gray-600">{review.role}</p>
                        </div>
                        <div className="flex items-center">
                          {[...Array(review.rating)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                          ))}
                          <span className="text-sm text-gray-500 mr-2">{review.date}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-700 leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">ابدأ رحلتك في عالم الذكاء الاصطناعي اليوم</h2>
          <p className="text-indigo-100 text-xl mb-8 max-w-2xl mx-auto">
            انضم إلى آلاف الطلاب الذين حولوا شغفهم بالذكاء الاصطناعي إلى مهارات عملية ومشاريع واقعية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-indigo-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl">
              ابدأ التعلم الآن - مجاناً
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white hover:text-indigo-600 transition-all">
              شاهد الدرس التجريبي
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">أكاديمية الذكاء الاصطناعي</span>
            </div>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              نحن نقدم أفضل الدورات التدريبية في مجال الذكاء الاصطناعي والتعلم الآلي، 
              مصممة من قبل خبراء الصناعة لمساعدتك على بناء مستقبلك المهني.
            </p>
            <div className="flex justify-center space-x-8 text-gray-400">
              <a href="#" className="hover:text-white transition-colors">الشروط والأحكام</a>
              <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-white transition-colors">اتصل بنا</a>
              <a href="#" className="hover:text-white transition-colors">الأسئلة الشائعة</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals */}
      {showAddModule && <AddModuleModal />}
      {showAddLesson && <AddLessonModal />}
      {editingModule && <EditModuleModal />}
      {editingLesson && <EditLessonModal />}
    </div>
  );
};

export default App;
